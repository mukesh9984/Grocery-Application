import { Component, OnInit } from '@angular/core';
import { NavigationService } from '../services/navigation.service';
import { addAdminProductTable } from '../models/models';
import { ActivatedRoute, Router } from '@angular/router';
import { AdminProductTableService } from '../admin-product-table.service';

@Component({
  selector: 'app-admin-add-product',
  templateUrl: './admin-add-product.component.html',
  styleUrls: ['./admin-add-product.component.css']
})
export class AdminAddProductComponent implements OnInit {

  product: addAdminProductTable = {

    id: '',

    nameOfProduct: '',

    descriptionOfProduct: '',

    categoryOfProduct: '',

    productQuantityAvailable: '',

    imageUrl: '',

    price: '',

    discountOnProduct: '',

    specificationOfProduct: ''



  }

  constructor(private navigationService:AdminProductTableService ,private router: Router,private route: ActivatedRoute) { }




  ngOnInit(): void {

    this.route.queryParams.subscribe(params => {

      if (params['product']) {

        this.product = JSON.parse(params['product']);

      }

    });

  }




  onSubmit() {

    if(this.product.id==''){

      this.navigationService.addProduct(this.product).subscribe(res => {

        console.log(res);

        this.navigationService.getAllproduct().subscribe(products => {

          this.product = {

            id: '',

    nameOfProduct: '',

    descriptionOfProduct: '',

    categoryOfProduct: '',

    productQuantityAvailable: '',

    imageUrl: '',

    price: '',

    discountOnProduct: '',

    specificationOfProduct: ''


          };

          this.router.navigate(['/admin-table']);

        });

      });

    }

    else{

      this.upadteProduct(this.product);

      this.router.navigate(['/admin-table']);

    }

   

  }

  upadteProduct(product: addAdminProductTable){

    this.navigationService.upadteProduct(product).subscribe(res=>{

      this.navigationService.getAllproduct();

    });

  }

}
