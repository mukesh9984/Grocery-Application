import { Component, OnInit } from '@angular/core';
import { SuggestedProduct, addAdminProductTable } from '../models/models';
import { NavigationService } from '../services/navigation.service';
import { subscribeOn } from 'rxjs';
import { UtilityService } from '../services/utility.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  suggestedProducts: SuggestedProduct[] = [
    {
      banerimage: 'Baner/Banner4.png',
      category: {
        id: 1,
        category: 'oil',
        subCategory: 'Edible oil',
      },
    },
    {
      banerimage: 'Baner/Banner3.png',
      category: {
        id: 0,
        category: 'Fruits',
        subCategory: 'Fresh-fruits',
      },
    },
    {
      banerimage: 'Baner/Banner2.png',
      category: {
        id: 1,
        category: 'Fruits',
        subCategory: 'Organic-fruits',
      },
    },
    
  ];
  filteredProducts: SuggestedProduct[] = [];
  products: addAdminProductTable[]=[];
  constructor(private navigationService: NavigationService,public utilityService: UtilityService ) {}

  ngOnInit(): void {

    this.filteredProducts = this.suggestedProducts; // Assign the default products initially
    this.getAllproduct();
    

  }
  getAllproduct(){
    this.navigationService.getAllproduct().subscribe(

      res => {

        this.products = res;

       

        console.log(res);

      }

    );
  }
  search(value: string) {

    value = value.toLowerCase();

    if (value.length > 0) {

      this.filteredProducts = this.suggestedProducts.filter((product) =>

       

        product.category.subCategory.toLowerCase().includes(value)

      );

    } else {

      this.filteredProducts = this.suggestedProducts; // Show all products when search value is empty

    }

  }
  handleSearch(result: any): void {

    // Process the search results here

    console.log('Search results:', result);

  }
  
  
}
