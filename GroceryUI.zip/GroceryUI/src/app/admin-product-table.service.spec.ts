import { TestBed } from '@angular/core/testing';

import { AdminProductTableService } from './admin-product-table.service';

describe('AdminProductTableService', () => {
  let service: AdminProductTableService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AdminProductTableService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
