import { Component, OnInit } from '@angular/core';
import { NavigationService } from '../services/navigation.service';
import { Router } from '@angular/router';
import { addAdminProductTable } from '../models/models';
import { AdminProductTableService } from '../admin-product-table.service';

@Component({
  selector: 'app-admin-table',
  templateUrl: './admin-table.component.html',
  styleUrls: ['./admin-table.component.css']
})
export class AdminTableComponent implements OnInit {

  error=false;

  product: addAdminProductTable = {

    id: '',

    nameOfProduct: '',

    descriptionOfProduct: '',

    categoryOfProduct: '',

    productQuantityAvailable: '',

    imageUrl: '',

    price: '',

    discountOnProduct: '',

    specificationOfProduct: ''




  }

  title = 'products';

  products: addAdminProductTable[] = [];

  constructor(private navigationService: AdminProductTableService ,private router: Router) { }




  ngOnInit(): void {

    this.getAllproduct();

  }

  getAllproduct() {

    this.navigationService.getAllproduct().subscribe(

      res => {

        this.products = res;

       

        console.log(res);

      }

    );

  }




  deleteProduct(id:string){

    this.navigationService.deleteProduct(id).subscribe(res=>{

      this.error=true;

      this.getAllproduct();

    })

  }




  editProduct(addproduct: addAdminProductTable) {

    this.router.navigate(['/admin-add-product'], { queryParams: { product: JSON.stringify(addproduct) } });

  }

  JSON: JSON = JSON



}
