import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Product } from './models/models';

@Injectable({
  providedIn: 'root'
})
export class SearchItemService {
  private apiUrl = 'https://localhost:7149/api/SearchItem/'; // Replace with your actual API endpoint


  constructor(private http: HttpClient) { }




  searchItems(query: string): Observable<Product[]> {

    // Make the API request to search for items

    const params = new HttpParams().set('query', query);

    return this.http.get<Product[]>(this.apiUrl, { params });

}
}
