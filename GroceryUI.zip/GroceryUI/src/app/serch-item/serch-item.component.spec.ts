import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SerchItemComponent } from './serch-item.component';

describe('SerchItemComponent', () => {
  let component: SerchItemComponent;
  let fixture: ComponentFixture<SerchItemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SerchItemComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SerchItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
