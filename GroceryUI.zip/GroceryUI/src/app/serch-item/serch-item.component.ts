import { Component, OnInit } from '@angular/core';
import { Product } from '../models/models';
import { Router } from '@angular/router';
import { SearchItemService } from '../search-item.service';

@Component({
  selector: 'app-serch-item',
  templateUrl: './serch-item.component.html',
  styleUrls: ['./serch-item.component.css']
})
export class SerchItemComponent implements OnInit {

  imageIndex: number = 1;

  query = '';

  searchResults: Product[] = [];




  constructor(private itemService : SearchItemService, private router: Router) {}
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

  onSearch(): void {

    if (this.query.trim() !== '') {

      this.itemService.searchItems(this.query).subscribe(

        (results: any) => {

          this.searchResults = results;

        },

        (error: any) => {

          console.log('Error searching items:', error);

        }

      );

    }

  }

  redirectToProduct(productId: number) {

    this.router.navigate(['/product-details'], { queryParams: { id: productId } });

  }

goToHome() {

  this.router.navigate(['/home']); // Replace '/' with the actual route path for your home page

}

}

