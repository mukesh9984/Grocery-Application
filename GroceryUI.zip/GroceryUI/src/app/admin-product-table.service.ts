import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { addAdminProductTable } from './models/models';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminProductTableService {

  baseurl = 'https://localhost:7149/api/Admin/';
  
  constructor(private http: HttpClient) { }

  getAllproduct():Observable<addAdminProductTable[]>{




    return this.http.get<addAdminProductTable[]>(this.baseurl);

  }




  addProduct(addProduct: addAdminProductTable):Observable<addAdminProductTable>{

    addProduct.id='00000000-0000-0000-0000-000000000000';

    return this.http.post<addAdminProductTable>(this.baseurl,addProduct);

  }




  deleteProduct(id:string):Observable<addAdminProductTable>{

    return this.http.delete<addAdminProductTable>(this.baseurl+id);

  }




  upadteProduct(product: addAdminProductTable):Observable<addAdminProductTable>{

    return this.http.put<addAdminProductTable>(this.baseurl+product.id,product);

  }
}
